module.exports = [
    {
        rules: {
            // Add rules here.
        }
    }
];
